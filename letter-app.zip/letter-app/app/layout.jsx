import './globals.css';
import { Inter } from 'next/font/google';
import Nav from './components/Nav';
import { Providers } from './providers';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: 'Letter App',
  description: 'Create and save letters to Google Drive',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>
          <div className="min-h-screen bg-gray-50">
            <Nav />
            <main className="container mx-auto py-8 px-4">{children}</main>
          </div>
        </Providers>
      </body>
    </html>
  );
}
