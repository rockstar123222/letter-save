// pages/index.js
// (Use the exact same code from Step 7 of the previous *Tailwind* answer)
// It includes Head, useSession, useState, handleSave, and Tailwind UI components.
import { useState } from 'react';
import { useSession, signIn, signOut } from 'next-auth/react';
import Head from 'next/head';

export default function Home() {
    const { data: session, status } = useSession();
    const [letterContent, setLetterContent] = useState('');
    const [fileName, setFileName] = useState('MyLetter.txt');
    const [isSaving, setIsSaving] = useState(false);
    const [saveStatus, setSaveStatus] = useState('');

    const handleSave = async () => {
         // ... (handleSave logic remains identical to previous Tailwind example)
         if (!letterContent.trim() || !fileName.trim()) {
            setSaveStatus('Error: File name and content cannot be empty.');
            return;
        }

        setIsSaving(true);
        setSaveStatus('Saving...');

        try {
            const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || '';
            const response = await fetch(`${apiBaseUrl}/api/drive/save`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fileName, content: letterContent }),
            });
            // ... (rest of handleSave logic) ...
             const data = await response.json();
             if (response.ok) {
                setSaveStatus(`Successfully saved! File ID: ${data.fileId}`);
             } else {
                throw new Error(data.error || 'Failed to save file.');
             }
        } catch (error) {
             console.error('Save error:', error);
             setSaveStatus(`Error: ${error.message}`);
        } finally {
             setIsSaving(false);
        }
    };

    if (status === 'loading') {
        return <div className="min-h-screen flex items-center justify-center"><p>Loading...</p></div>;
    }

    if (!session) {
        // --- Unauthenticated View (Tailwind) ---
        return (
             <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-indigo-100 via-white to-green-100 p-6">
                 <Head><title>Login - Letter Editor</title></Head>
                 <main className="text-center bg-white p-10 rounded-xl shadow-2xl">
                     <h1 className="text-4xl font-bold text-gray-800 mb-5">Letter Editor</h1>
                     <p className="text-gray-600 mb-8">Sign in with Google to craft and save your letters directly to Google Drive.</p>
                     <button
                         onClick={() => signIn('google')}
                         className="px-7 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-200 ease-in-out transform hover:-translate-y-0.5"
                     >
                         Sign in with Google
                     </button>
                 </main>
             </div>
        );
    }

    // --- Authenticated View (Tailwind) ---
    return (
        <div className="min-h-screen flex flex-col items-center bg-gray-100 py-6 px-4 sm:px-6 lg:px-8">
            <Head>
                <title>Letter Editor - {session.user.email}</title>
                <meta name="description" content="Edit and save letters to Google Drive" />
            </Head>

            {/* Header */}
            <header className="w-full max-w-5xl flex justify-between items-center p-4 bg-white rounded-t-lg shadow mb-1">
                <p className="text-sm text-gray-600 truncate">
                    Signed in as: <span className="font-medium">{session.user.email}</span>
                </p>
                <button
                    onClick={() => signOut()}
                    className="flex-shrink-0 ml-4 px-4 py-1.5 bg-red-500 text-white text-xs font-medium rounded-md shadow hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-red-400 transition"
                >
                    Sign out
                </button>
            </header>

            {/* Editor Main Area */}
            <main className="w-full max-w-5xl p-6 bg-white rounded-b-lg shadow-lg flex flex-col items-center flex-1">
                <h1 className="text-3xl font-semibold text-gray-800 mb-6 self-start">
                    Compose Your Letter
                </h1>

                {/* File Name Input */}
                <div className="w-full mb-5">
                    <label htmlFor="fileName" className="block text-sm font-medium text-gray-700 mb-1">File Name</label>
                    <input
                        type="text" id="fileName" value={fileName}
                        onChange={(e) => setFileName(e.target.value)}
                        disabled={isSaving}
                        className="w-full p-2.5 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 disabled:bg-gray-200 transition"
                        placeholder="e.g., ProjectNotes.txt"
                     />
                 </div>

                {/* Text Area */}
                <textarea
                    value={letterContent}
                    onChange={(e) => setLetterContent(e.target.value)}
                    rows={18} placeholder="Start writing..."
                    disabled={isSaving}
                    className="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 mb-6 text-base font-mono resize-y min-h-[400px] disabled:bg-gray-200 transition"
                />

                {/* Save Button & Status */}
                <div className="w-full flex flex-col sm:flex-row items-center justify-between mt-2">
                     <button
                         onClick={handleSave}
                         disabled={isSaving || !letterContent.trim() || !fileName.trim()}
                         className="w-full sm:w-auto px-8 py-3 bg-green-600 text-white font-semibold rounded-md shadow-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed transition duration-200 ease-in-out order-1 sm:order-2"
                     >
                         {isSaving ? 'Saving...' : 'Save to Google Drive'}
                     </button>
                     {saveStatus && (
                         <p className={`mt-3 sm:mt-0 text-sm order-2 sm:order-1 ${saveStatus.startsWith('Error:') ? 'text-red-600 font-medium' : 'text-green-700'}`}>
                             {saveStatus}
                         </p>
                    )}
                </div>
            </main>
        </div>
    );
}