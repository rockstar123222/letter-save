// FILE: app/api/drive/save/route.js
import { google } from 'googleapis';
import { getToken } from 'next-auth/jwt'; // Use JWT strategy to get token server-side
import { NextResponse } from 'next/server'; // Use NextResponse for responses in App Router

// Secret used to encrypt the NextAuth JWT - must match the one in [...nextauth] route
const secret = process.env.NEXTAUTH_SECRET;

// Handler for POST requests to save the file
export async function POST(request) {
    console.log("[Save API] Received POST request.");

    // 1. Authenticate the user using the JWT from the incoming request
    // The 'request' object here is the NextRequest from next/server
    const token = await getToken({ req: request, secret });

    // Verify the token and ensure it contains the access token needed for Google API
    if (!token || !token.accessToken) {
        console.error("[Save API] Authentication failed: No valid token or accessToken found.");
        return NextResponse.json({ error: 'Authentication required or token is invalid.' }, { status: 401 });
    }

    // Optional but recommended: Check for token expiry
    // Note: Proper refresh logic should ideally live within the [...nextauth] route's JWT callback
    if (token.accessTokenExpires && Date.now() > token.accessTokenExpires) {
        console.error("[Save API] Authentication failed: Access token has expired.");
        return NextResponse.json({ error: 'Session expired. Please sign in again.' }, { status: 401 });
    }
    console.log(`[Save API] User authenticated via token: ${token.email}`); // Log user email for audit/debug

    // 2. Parse the request body to get file content and name
    let content, fileName;
    try {
         const body = await request.json(); // Parse JSON body from the NextRequest
         content = body.content;
         fileName = body.fileName;

         // Basic validation
         if (typeof content !== 'string' || typeof fileName !== 'string' || !fileName.trim()) {
            throw new Error('Invalid or missing file content or fileName.');
        }
    } catch (error) {
         console.error("[Save API] Error parsing request body:", error.message);
         return NextResponse.json({ error: `Invalid request body: ${error.message}` }, { status: 400 });
    }

    // Sanitize filename and ensure .txt extension
    const cleanFileName = fileName.trim().endsWith('.txt') ? fileName.trim() : `${fileName.trim()}.txt`;
    console.log(`[Save API] Preparing to save file: "${cleanFileName}"`);

    // 3. Interact with the Google Drive API
    try {
        // Set up the Google OAuth2 client
        const oauth2Client = new google.auth.OAuth2();
        // Set the credentials for the client using the user's access token from the JWT
        oauth2Client.setCredentials({ access_token: token.accessToken });

        // Create a Drive API client instance authorized with the user's credentials
        const drive = google.drive({ version: 'v3', auth: oauth2Client });

        // Define the metadata for the new file
        const fileMetadata = {
            name: cleanFileName,
            mimeType: 'text/plain', // Saving as plain text
            // Optional: Specify a parent folder ID to save into a specific folder
            // parents: ['YOUR_FOLDER_ID_HERE'] // Requires drive scope, not just drive.file scope
        };

        // Define the media content (the actual file body)
        const media = {
            mimeType: 'text/plain',
            body: content, // The text content from the request
        };

        // Use the drive.files.create method to upload the file
        console.log(`[Save API] Calling drive.files.create for file: "${cleanFileName}"`);
        const driveResponse = await drive.files.create({
            resource: fileMetadata,
            media: media,
            fields: 'id, name, webViewLink', // Specify fields to get back from the API
        });

        console.log(`[Save API] Google Drive API Success! File created. ID: ${driveResponse.data.id}, Name: ${driveResponse.data.name}`);

        // 4. Send a success response back to the client
        return NextResponse.json({
            message: 'File saved successfully to Google Drive!',
            fileId: driveResponse.data.id,
            fileName: driveResponse.data.name,
            fileLink: driveResponse.data.webViewLink, // Provide a link to view the file
        }, { status: 200 });

    } catch (error) {
        // 5. Handle errors during the Google Drive API interaction
        console.error('[Save API] Google Drive API interaction failed:', error.response ? JSON.stringify(error.response.data, null, 2) : error.message); // Log detailed error
        let statusCode = 500;
        let errorMessage = 'An unexpected error occurred while saving the file to Google Drive.';

        // Provide more specific error messages based on Google API response
        if (error.response) {
             statusCode = error.response.status || 500;
             if (statusCode === 401 || statusCode === 403) {
                 errorMessage = 'Google Drive authorization failed. Your session might be invalid or permissions insufficient. Please sign out and sign back in.';
             } else if (error.response.data?.error?.message) {
                 errorMessage = `Google Drive API Error (${statusCode}): ${error.response.data.error.message}`;
             }
        } else if (error.code === 'ENOTFOUND' || error.code === 'ETIMEDOUT') {
            errorMessage = 'Could not connect to Google Drive API. Please check your network connection.';
            statusCode = 503; // Service Unavailable
        } else if (error.message) {
            errorMessage = error.message; // Use generic error message if no specific details
        }

        // Send an error response back to the client
        return NextResponse.json({ error: errorMessage }, { status: statusCode });
    }
}