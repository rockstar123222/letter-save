
import NextAuth from 'next-auth';
import GoogleProvider from 'next-auth/providers/google';
import fs from 'fs';
import path from 'path';

console.log("✅ [NextAuth Route] Initializing: app/api/auth/[...nextauth]/route.js");

function getGoogleCredentials() {
    const credentialsPath = path.join(process.cwd(), 'credentials.json');
    console.log(`[NextAuth Route] Attempting to load credentials from: ${credentialsPath}`);

    if (!fs.existsSync(credentialsPath)) {
        console.error(`❌ [NextAuth Route] FATAL ERROR: credentials.json not found at ${credentialsPath}. Google sign-in WILL FAIL.`);
        return { clientId: "", clientSecret: "" };
    }

    try {
        const rawData = fs.readFileSync(credentialsPath);
        const credentials = JSON.parse(rawData.toString());

        if (credentials?.web?.client_id && credentials?.web?.client_secret) {
            console.log("✅ [NextAuth Route] Successfully loaded Google credentials from credentials.json.");
            return {
                clientId: credentials.web.client_id,
                clientSecret: credentials.web.client_secret,
            };
        } else {
            console.error("❌ [NextAuth Route] ERROR: Invalid credentials.json structure. Expected 'web.client_id' and 'web.client_secret'. Found:", JSON.stringify(credentials));
            return { clientId: "", clientSecret: "" };
        }
    } catch (error) {
        console.error("❌ [NextAuth Route] ERROR: Failed to read or parse credentials.json:", error);
        return { clientId: "", clientSecret: "" };
    }
}

const googleCredentials = getGoogleCredentials();

export const authOptions = {
    providers: [
        GoogleProvider({
            clientId: googleCredentials.clientId, 
            clientSecret: googleCredentials.clientSecret, // Uses loaded value or "" if failed
            authorization: {
                params: {
                    prompt: "consent",       
                    access_type: "offline", 
                    response_type: "code",   
                    scope: 'openid email profile https://www.googleapis.com/auth/drive.file', // Essential scopes + Drive access
                },
            },
        }),
       
    ],

    secret: process.env.NEXTAUTH_SECRET,

    session: {
        strategy: "jwt",
    },

    callbacks: {
        async jwt({ token, user, account, profile }) {
            if (account && user) {
                token.accessToken = account.access_token;
                token.refreshToken = account.refresh_token;
                token.accessTokenExpires = account.expires_at * 1000; // Convert expiry to milliseconds
                token.id = user.id; 
                console.log("[NextAuth JWT Callback] Token updated on sign-in.");
            }



            return token; 
        },

        async session({ session, token }) {
            if (token) {
                session.user.id = token.id; 
                session.error = token.error; // Pass potential token errors (like refresh failure)
            }
            return session; 
        },
    },



}; 


let isConfigValid = true;
if (!process.env.NEXTAUTH_SECRET) {
    console.error("❌ [NextAuth Route] FATAL ERROR: NEXTAUTH_SECRET environment variable is not set! Authentication will fail.");
    isConfigValid = false;
}
if (!googleCredentials.clientId || !googleCredentials.clientSecret) {
     console.warn("⚠️ [NextAuth Route] WARNING: Google Client ID or Secret is missing or failed to load. Google Sign-In will be non-functional.");
     isConfigValid = false; 
}


const handler = NextAuth(authOptions);


export { handler as GET, handler as POST };
console.log(`✅ [NextAuth Route] Exported GET and POST handlers. Config valid for Google: ${isConfigValid}`);
