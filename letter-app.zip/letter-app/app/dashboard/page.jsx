'use client';

import { useSession } from 'next-auth/react';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { getLettersList } from '../lib/driveapi';

export default function Dashboard() {
  const { data: session, status } = useSession();
  const [letters, setLetters] = useState([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/');
    }

    if (status === 'authenticated') {
      fetchLetters();
    }
  }, [status, router]);

  const fetchLetters = async () => {
    try {
      const lettersList = await getLettersList(session.accessToken);
      setLetters(lettersList);
    } catch (error) {
      console.error('Error fetching letters:', error);
    } finally {
      setLoading(false);
    }
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Your Letters</h1>
        <Link href="/letter/new" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md">
          Create New Letter
        </Link>
      </div>

      {letters.length === 0 ? (
        <div className="bg-white p-8 rounded-lg shadow text-center">
          <p className="text-xl mb-4">You haven't created any letters yet.</p>
          <Link href="/letter/new" className="text-blue-600 hover:underline">
            Create your first letter
          </Link>
        </div>
      ) : (
        <div className="grid gap-4">
          {letters.map((letter) => (
            <Link 
              href={`/letter/${letter.id}`} 
              key={letter.id}
              className="bg-white p-6 rounded-lg shadow flex justify-between items-center hover:shadow-md transition-shadow"
            >
              <div>
                <h2 className="font-semibold text-xl">{letter.name}</h2>
                <p className="text-gray-500">Last modified: {new Date(letter.modifiedTime).toLocaleString()}</p>
              </div>
              <div className="text-blue-600">Edit →</div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}