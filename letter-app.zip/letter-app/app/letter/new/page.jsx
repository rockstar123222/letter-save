'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import LetterEditor from '../../components/LetterEditor';
import { createLetter } from '../../lib/driveapi';

export default function NewLetter() {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [title, setTitle] = useState('Untitled Letter');
  const [content, setContent] = useState('');
  const [saving, setSaving] = useState(false);

  if (status === 'unauthenticated') {
    router.push('/');
    return null;
  }

  if (status === 'loading') {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-xl">Loading...</div>
      </div>
    );
  }

  const handleSave = async () => {
    if (!title || !content) {
      alert('Please add a title and content to your letter');
      return;
    }

    setSaving(true);
    try {
      await createLetter(title, content, session.accessToken);
      router.push('/dashboard');
    } catch (error) {
      console.error('Error saving letter:', error);
      alert('Failed to save letter. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="text-2xl font-bold bg-transparent border-b border-gray-300 focus:border-blue-500 focus:outline-none py-1 px-2"
        />
        <button
          onClick={handleSave}
          disabled={saving}
          className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md disabled:bg-blue-400"
        >
          {saving ? 'Saving...' : 'Save to Drive'}
        </button>
      </div>

      <LetterEditor content={content} setContent={setContent} />
    </div>
  );
}
