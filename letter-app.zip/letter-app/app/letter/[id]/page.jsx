'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import LetterEditor from '../../components/LetterEditor';
import { getLetter, updateLetter } from '../../lib/driveapi';

export default function EditLetter({ params }) {
  const { id } = params;
  const router = useRouter();
  const { data: session, status } = useSession();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/');
    }

    if (status === 'authenticated' && id) {
      fetchLetter();
    }
  }, [status, id, router]);

  const fetchLetter = async () => {
    try {
      const letter = await getLetter(id, session.accessToken);
      setTitle(letter.name);
      setContent(letter.content);
    } catch (error) {
      console.error('Error fetching letter:', error);
      alert('Failed to load letter. Redirecting to dashboard.');
      router.push('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!title || !content) {
      alert('Please add a title and content to your letter');
      return;
    }

    setSaving(true);
    try {
      await updateLetter(id, title, content, session.accessToken);
      router.push('/dashboard');
    } catch (error) {
      console.error('Error updating letter:', error);
      alert('Failed to update letter. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="text-2xl font-bold bg-transparent border-b border-gray-300 focus:border-blue-500 focus:outline-none py-1 px-2"
        />
        <button
          onClick={handleSave}
          disabled={saving}
          className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md disabled:bg-blue-400"
        >
          {saving ? 'Saving...' : 'Update Letter'}
        </button>
      </div>

      <LetterEditor content={content} setContent={setContent} />
    </div>
  );
}