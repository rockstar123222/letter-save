import Link from 'next/link';
import AuthButton from './components/AuthButton';

export default function Home() {
  return (
    <div className="max-w-4xl mx-auto text-center">
      <h1 className="text-4xl font-bold mb-6">Welcome to Letter App</h1>
      <p className="text-xl mb-8">
        Create, edit, and save your letters directly to Google Drive
      </p>
      <div className="flex justify-center">
        <AuthButton />
      </div>
      <div className="mt-12">
        <h2 className="text-2xl font-semibold mb-4">Features</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-bold mb-2">Google Authentication</h3>
            <p>Securely log in with your Google account</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-bold mb-2">Simple Editor</h3>
            <p>Create and edit your letters with our intuitive editor</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-bold mb-2">Google Drive Integration</h3>
            <p>Save your letters directly to your Google Drive</p>
          </div>
        </div>
      </div>
    </div>
  );
}