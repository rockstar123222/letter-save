'use client';

import Link from 'next/link';
import { useSession } from 'next-auth/react';

export default function Nav() {
  const { data: session } = useSession();

  return (
    <nav className="bg-white shadow">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-xl font-bold text-blue-600">
          Letter App
        </Link>
        
        <div className="flex items-center gap-6">
          {session ? (
            <>
              <Link href="/dashboard" className="text-gray-700 hover:text-blue-600">
                Dashboard
              </Link>
              <Link href="/letter/new" className="text-gray-700 hover:text-blue-600">
                New Letter
              </Link>
              <div className="flex items-center">
                {session.user?.image && (
                  <img 
                    src={session.user.image} 
                    alt={session.user.name || 'User'} 
                    className="w-8 h-8 rounded-full mr-2"
                  />
                )}
                <span className="text-sm text-gray-600">{session.user?.name}</span>
              </div>
            </>
          ) : (
            <Link href="/" className="text-gray-700 hover:text-blue-600">
              Home
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}