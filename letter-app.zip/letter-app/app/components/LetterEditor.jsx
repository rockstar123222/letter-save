'use client';

import { useState, useEffect } from 'react';

export default function LetterEditor({ content = '', setContent }) {
  const [editorContent, setEditorContent] = useState(content);

  useEffect(() => {
    setEditorContent(content);
  }, [content]);

  const handleChange = (e) => {
    const newContent = e.target.value;
    setEditorContent(newContent);
    setContent(newContent);
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <textarea
        value={editorContent}
        onChange={handleChange}
        className="w-full h-96 p-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        placeholder="Start writing your letter here..."
      />
    </div>
  );
}
